## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(mapppdr)
library(dplyr)
library(tidyr)
library(RefManageR)
library(sf)
library(htmlwidgets)

## ---- eval = FALSE------------------------------------------------------------
#  library(tidyverse)
#  library(RefManageR)
#  library(sf)
#  library(htmlwidgets)

## -----------------------------------------------------------------------------
data(penguin_obs)
head(penguin_obs)

## -----------------------------------------------------------------------------
chinstrap_counts <- penguin_obs %>%
  dplyr::filter(type == "nests" & year %in% c(2000:2010) & species_id == "CHPE") %>%
  left_join(sites, by = "site_id") %>%
  dplyr::filter(ccamlr_id == "48.2")
head(chinstrap_counts)

## -----------------------------------------------------------------------------
ACUN_area_counts <- sites_sf %>%
  mutate(ACUN_distance = as.numeric(sf::st_distance(sites_sf, sites_sf %>% 
    dplyr::filter(site_id == "ACUN")))) %>%
  dplyr::filter(ACUN_distance <= 10000) %>%
  dplyr::select(site_id) %>%
  inner_join(penguin_obs, by = "site_id")
st_geometry(ACUN_area_counts) <- NULL
glimpse(ACUN_area_counts)

## -----------------------------------------------------------------------------
coria_citations <- persons %>%
  dplyr::filter(family == "Coria" & given == "Néstor R.") %>%
  inner_join(citation_persons, by = "person_id") %>%
  dplyr::select(citekey) %>%
  inner_join(articles, by = "citekey") %>%
  dplyr::select(citekey, journal, doi, title)
glimpse(coria_citations)

coria_counts <- penguin_obs %>%
  inner_join(coria_citations %>% dplyr::select(citekey), by = "citekey") 
head(coria_counts)

## ----chunk1, results = 'hide'-------------------------------------------------
out <- mapppd_bib[mapppd_bib$key %in% coria_citations$citekey]
RefManageR::WriteBib(out, file = "Coria_citations.bib")
print(out, .opts = list(bib.style = "authoryear", style = "markdown"))

## ----ref.label = 'chunk1', results = 'asis', echo = F-------------------------
out <- mapppd_bib[mapppd_bib$key %in% coria_citations$citekey]
RefManageR::WriteBib(out, file = "Coria_citations.bib")
print(out, .opts = list(bib.style = "authoryear", style = "markdown"))

## ---- eval = FALSE------------------------------------------------------------
#  penmap("ADPE")

## ---- echo = FALSE, out.width = "50%", fig.align = 'center'-------------------
knitr::include_graphics("leaflet.png")

## ---- eval = FALSE------------------------------------------------------------
#  htmlwidgets::saveWidget(penmap("ADPE"), file = "~/Desktop/ADPE_map.html")

